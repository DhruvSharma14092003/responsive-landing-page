# Responsive Landing Page 🚀

This is a simple responsive landing page created using HTML5 and CSS3 as part of the Web Development Internship task.

## 🧾 Features

- Responsive design using Flexbox and Media Queries
- Clean layout with header, hero section, and footer
- Mobile friendly navigation
- Styled with custom CSS

## 📁 Files

- `index.html` — Main HTML file
- `style.css` — Styling file for layout and responsiveness

## 📱 Tools Used

- HTML5
- CSS3 (Flexbox & Grid)
- Media Queries
- VS Code & Live Server

---

**Made with ❤️ by Dhruv Sharma**
